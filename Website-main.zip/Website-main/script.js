// Future animations or interactions
console.log("Portfolio loaded 🚀");
